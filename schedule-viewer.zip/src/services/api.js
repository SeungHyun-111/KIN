const API_BASE =
  "https://script.google.com/macros/s/AKfycbx5CBaKJtMMmVSwZ-q_6d7iMurb3dAjrFzgdMtFkIEUwEBkEaFQcz8RMHmUj4dLjDAYeQ/exec";

async function request(url, options = {}) {
  const res = await fetch(url, {
    method: options.method || "GET",
    headers: options.headers || {},
    body: options.body,
  });

  let data = null;

  try {
    data = await res.json();
  } catch (err) {
    throw new Error("응답을 JSON으로 읽지 못했습니다.");
  }

  if (!res.ok || !data?.ok) {
    throw new Error(data?.error || "API 요청 중 오류가 발생했습니다.");
  }

  return data;
}

export async function fetchList() {
  const url = `${API_BASE}?action=list`;
  const data = await request(url);
  return data.data || [];
}

export async function addItem(payload) {
  const url = `${API_BASE}?action=add`;
  const data = await request(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });
  return data.added;
}

export async function updateItem(payload) {
  const url = `${API_BASE}?action=update`;
  const data = await request(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });
  return data.updated;
}

export async function deleteItem(id) {
  const url = `${API_BASE}?action=delete`;
  const data = await request(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ id }),
  });
  return data.removed;
}

export async function commitOverlay(overlay) {
  const url = `${API_BASE}?action=commit`;
  const data = await request(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ overlay }),
  });
  return data.result;
}