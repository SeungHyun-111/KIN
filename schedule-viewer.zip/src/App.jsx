import { useEffect, useMemo, useState } from "react";
import { fetchList } from "./services/api";
import FilterBar from "./components/FilterBar";

const CACHE_KEY = "schedule_rows_cache_v1";
const CACHE_TIME_KEY = "schedule_rows_cache_time_v1";

function normalizeText(value = "") {
  return String(value).toLowerCase().trim();
}

function normalizeMonthValue(value = "") {
  return String(value).trim().replace(/\//g, "-").slice(0, 7);
}

function getMonthValue(dateStr = "") {
  return normalizeMonthValue(dateStr);
}

function getStatusValue(status = "") {
  const s = String(status).trim();
  return s || "검토";
}

function readCache() {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function readCacheTime() {
  return localStorage.getItem(CACHE_TIME_KEY) || "";
}

function writeCache(rows) {
  localStorage.setItem(CACHE_KEY, JSON.stringify(rows));
  localStorage.setItem(CACHE_TIME_KEY, new Date().toLocaleString("ko-KR"));
}

export default function App() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [cacheTime, setCacheTime] = useState("");

  const [month, setMonth] = useState("");
  const [org, setOrg] = useState("");
  const [time, setTime] = useState("");
  const [status, setStatus] = useState("");
  const [keyword, setKeyword] = useState("");

  useEffect(() => {
    let alive = true;

    async function init() {
      try {
        const cachedRows = readCache();
        const cachedTime = readCacheTime();

        if (cachedRows.length > 0) {
          if (!alive) return;
          setRows(cachedRows);
          setCacheTime(cachedTime);
          setLoading(false);
          return;
        }

        setLoading(true);

        const data = await fetchList();

        if (!alive) return;

        setRows(data);
        writeCache(data);
        setCacheTime(readCacheTime());
      } catch (err) {
        if (!alive) return;
        setError(err.message || "데이터를 불러오지 못했습니다.");
      } finally {
        if (!alive) return;
        setLoading(false);
      }
    }

    init();

    return () => {
      alive = false;
    };
  }, []);

  async function handleRefresh() {
    try {
      setRefreshing(true);
      setError("");

      const data = await fetchList();
      setRows(data);
      writeCache(data);
      setCacheTime(readCacheTime());
    } catch (err) {
      setError(err.message || "데이터를 불러오지 못했습니다.");
    } finally {
      setRefreshing(false);
    }
  }

  const months = useMemo(() => {
    return [...new Set(rows.map((row) => getMonthValue(row.requestDate)).filter(Boolean))].sort();
  }, [rows]);

  const orgs = useMemo(() => {
    return [...new Set(rows.map((row) => String(row.orgName || "").trim()).filter(Boolean))].sort();
  }, [rows]);

  const times = useMemo(() => {
    const list = [...new Set(rows.map((row) => String(row.requestTimeBand || "").trim()).filter(Boolean))];
    return list.sort((a, b) => {
      const aa = parseInt(a.replace(/[^\d]/g, ""), 10);
      const bb = parseInt(b.replace(/[^\d]/g, ""), 10);
      return aa - bb;
    });
  }, [rows]);

  const statuses = useMemo(() => {
    return [...new Set(rows.map((row) => getStatusValue(row.status)).filter(Boolean))].sort();
  }, [rows]);

  useEffect(() => {
    if (!month && months.length > 0) {
      setMonth(months[0]);
    }
  }, [month, months]);

  const filteredRows = useMemo(() => {
    const keywordTokens = normalizeText(keyword)
      .split(/\s+/)
      .filter(Boolean);

    return rows.filter((row) => {
      const rowMonth = getMonthValue(row.requestDate);
      const rowOrg = String(row.orgName || "").trim();
      const rowTime = String(row.requestTimeBand || "").trim();
      const rowStatus = getStatusValue(row.status);

      const itemText = [
        row.scheduleCodeName,
        row.opinion,
        row.orgName,
        row.mdCategory,
        row.id,
      ]
        .map((v) => String(v || ""))
        .join(" ");

      const normalizedItemText = normalizeText(itemText);

      if (month && rowMonth !== month) return false;
      if (org && rowOrg !== org) return false;
      if (time && rowTime !== time) return false;
      if (status && rowStatus !== status) return false;

      if (
        keywordTokens.length > 0 &&
        !keywordTokens.every((token) => normalizedItemText.includes(token))
      ) {
        return false;
      }

      return true;
    });
  }, [rows, month, org, time, status, keyword]);

  return (
    <div className="app">
      <header className="app-header">
        <h1>월간 사전 편성 회의_편성팀</h1>
      </header>

      <main className="app-body">
        {loading && <div className="state-box">불러오는 중...</div>}

        {!loading && (
          <>
            {error && <div className="state-box error">{error}</div>}

            <FilterBar
              month={month}
              setMonth={setMonth}
              org={org}
              setOrg={setOrg}
              time={time}
              setTime={setTime}
              status={status}
              setStatus={setStatus}
              keyword={keyword}
              setKeyword={setKeyword}
              months={months}
              orgs={orgs}
              times={times}
              statuses={statuses}
              onRefresh={handleRefresh}
              refreshing={refreshing}
              commitCount={0}
              onCommit={() => {}}
              committing={false}
            />

            <div className="top-action-bar">
              <div className="top-action-bar__left">
                <div className="cache-info">
                  마지막 불러온 시각: {cacheTime || "없음"}
                </div>
              </div>
            </div>

            <div className="state-box">
              총 <strong>{filteredRows.length}</strong>건 조회되었습니다.
            </div>

            <div className="list-wrap">
              {filteredRows.length === 0 ? (
                <div className="empty">조건에 맞는 데이터가 없습니다.</div>
              ) : (
                filteredRows.map((row, idx) => (
                  <div className="list-card" key={row.id || idx}>
                    <div><strong>일자:</strong> {row.requestDate || "-"}</div>
                    <div><strong>시간:</strong> {row.requestTimeBand || "-"}</div>
                    <div><strong>조직:</strong> {row.orgName || "-"}</div>
                    <div><strong>아이템:</strong> {row.scheduleCodeName || "-"}</div>
                    <div><strong>상태:</strong> {getStatusValue(row.status)}</div>
                    <div><strong>의견:</strong> {row.opinion || "-"}</div>
                    <div><strong>ID:</strong> {row.id || "-"}</div>
                  </div>
                ))
              )}
            </div>
          </>
        )}
      </main>
    </div>
  );
}